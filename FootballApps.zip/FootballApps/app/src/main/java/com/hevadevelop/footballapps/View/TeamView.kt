package com.hevadevelop.footballapps.View

import com.hevadevelop.footballapps.Model.Events
import com.hevadevelop.footballapps.Model.Teams

interface TeamView {

    fun showLoading()
    fun hideLoading()
    fun showDetailMatch(data: List<Events>?)
    fun showTeamListHome(data: List<Teams>?)
    fun showTeamListAway(data: List<Teams>?)
}