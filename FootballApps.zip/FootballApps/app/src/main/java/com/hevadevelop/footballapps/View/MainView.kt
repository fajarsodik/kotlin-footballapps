package com.hevadevelop.footballapps.View

import com.hevadevelop.footballapps.Model.Events
import com.hevadevelop.footballapps.Model.Teams

interface MainView {
    fun showLoading()
    fun hideLoading()
    fun showEventList(data: List<Events>?)
}