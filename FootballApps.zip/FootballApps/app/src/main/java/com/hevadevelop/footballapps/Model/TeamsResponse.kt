package com.hevadevelop.footballapps.Model

data class TeamsResponse (val teams: List<Teams>)