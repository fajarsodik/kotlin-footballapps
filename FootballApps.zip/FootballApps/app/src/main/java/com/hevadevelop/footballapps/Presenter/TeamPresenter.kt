package com.hevadevelop.footballapps.Presenter

import com.google.gson.Gson
import com.hevadevelop.footballapps.Api.ApiRepository
import com.hevadevelop.footballapps.Api.TheSportDb
import com.hevadevelop.footballapps.Model.EventsResponse
import com.hevadevelop.footballapps.Model.TeamsResponse
import com.hevadevelop.footballapps.View.TeamView
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class TeamPresenter(private val view: TeamView,
                    private val apiRepository: ApiRepository,
                    private val gson: Gson) {

    fun getMatchList(typeList: String?, param: String?, valueParam: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                    .doRequest(TheSportDb.getMatch(typeList, param, valueParam)),
                    EventsResponse::class.java
            )

            uiThread {
                view.hideLoading()
                view.showDetailMatch(data.events)
            }
        }
    }

    fun getHomeDetail(typeList: String?, param: String?, valueParam: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                    .doRequest(TheSportDb.getMatch(typeList, param, valueParam)),
                    TeamsResponse::class.java
            )

            uiThread {
                view.hideLoading()
                view.showTeamListHome(data.teams)
            }
        }
    }

    fun getAwayDetail(typeList: String?, param: String?, valueParam: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                    .doRequest(TheSportDb.getMatch(typeList, param, valueParam)),
                    TeamsResponse::class.java
            )

            uiThread {
                view.hideLoading()
                view.showTeamListAway(data.teams)
            }
        }
    }
}