package com.hevadevelop.footballapps.Model

data class EventsResponse (
        val events: List<Events>
)